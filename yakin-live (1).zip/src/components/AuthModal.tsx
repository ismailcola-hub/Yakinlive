import React, { useState } from 'react';
import { Smartphone, X, ArrowLeft, CheckCircle2, ShieldCheck, Sparkles, Send } from 'lucide-react';
import { User } from '../types/index.ts';
import { validatePhoneNumber, validateOtp } from '../utils/auth.ts';
import confetti from 'canvas-confetti';
import { playCoinSound } from '../utils/audio.ts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: Partial<User>) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [method, setMethod] = useState<'menu' | 'phone' | 'otp'>('menu');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+90');
  const [otpCode, setOtpCode] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleGoogleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      onLoginSuccess({
        id: 'user_google_' + Date.now(),
        displayName: 'İsmail Çolak',
        username: 'ismailcola',
        avatar: '⭐',
        isVerified: true,
      });
      playCoinSound();
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } catch {
        // fallback
      }
      setLoading(false);
      onClose();
    }, 900);
  };

  const handleFacebookLogin = () => {
    setLoading(true);
    setTimeout(() => {
      onLoginSuccess({
        id: 'user_fb_' + Date.now(),
        displayName: 'Yakın Misafir (Facebook)',
        username: 'fb_user_' + Math.floor(Math.random() * 1000),
        avatar: '💙',
        isVerified: true,
      });
      playCoinSound();
      setLoading(false);
      onClose();
    }, 900);
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!validatePhoneNumber(phoneNumber)) {
      setErrorMsg('Lütfen 10 haneli geçerli bir telefon numarası girin (Örn: 555 123 4567)');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setMethod('otp');
      setIsTimerRunning(true);
      setCountdown(60);
      // simulate pre-fill code hint for user testing convenience
      setOtpCode('123456');
    }, 700);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!validateOtp(otpCode)) {
      setErrorMsg('Lütfen 6 haneli doğrulama kodunu eksiksiz girin.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const cleanPhone = phoneNumber.replace(/\D/g, '').slice(-4);
      onLoginSuccess({
        id: 'user_phone_' + Date.now(),
        displayName: `Kullanıcı_${cleanPhone}`,
        username: `tel_${cleanPhone}`,
        avatar: '📱',
        isVerified: true,
      });
      playCoinSound();
      try {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } catch {
        // fallback
      }
      setLoading(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-sm bg-[#161124] border border-[#3b2b52] rounded-2xl shadow-2xl p-5 text-white my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#2d2243]">
          <div className="flex items-center gap-2">
            {method !== 'menu' && (
              <button
                onClick={() => {
                  setMethod('menu');
                  setErrorMsg(null);
                }}
                className="p-1 rounded-lg bg-[#241c38] hover:bg-[#32274d] text-gray-300 mr-1"
                aria-label="Geri Dön"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <Sparkles className="w-5 h-5 text-pink-400" />
            <h3 className="font-extrabold text-base">
              {method === 'menu' && 'Yakın Live Giriş Yap'}
              {method === 'phone' && 'Telefonla Giriş'}
              {method === 'otp' && 'SMS Kodunu Girin'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#241c38] hover:bg-[#32274d] text-gray-400 hover:text-white transition-colors"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mt-3 p-2.5 rounded-xl bg-rose-950/80 border border-rose-500 text-rose-200 text-xs font-bold animate-shake">
            {errorMsg}
          </div>
        )}

        {/* STATE 1: MAIN MENU (Google, Facebook, Phone) */}
        {method === 'menu' && (
          <div className="mt-4 space-y-3">
            <p className="text-xs text-purple-200 text-center mb-3">
              Yayın açmak, hediyeler göndermek ve arkadaşlarınızı takip etmek için giriş yapın.
            </p>

            {/* Google Sign-In Button */}
            <button
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl bg-white text-gray-800 font-extrabold text-xs shadow-md hover:bg-gray-100 active:scale-98 transition-all flex items-center justify-center gap-3"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{loading ? 'Bağlanıyor...' : 'Google ile Devam Et'}</span>
            </button>

            {/* Facebook Sign-In Button */}
            <button
              onClick={handleFacebookLogin}
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl bg-[#1877F2] text-white font-extrabold text-xs shadow-md hover:bg-[#166fe5] active:scale-98 transition-all flex items-center justify-center gap-3"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              <span>{loading ? 'Bağlanıyor...' : 'Facebook ile Devam Et'}</span>
            </button>

            {/* Phone Login Button */}
            <button
              onClick={() => {
                setMethod('phone');
                setErrorMsg(null);
              }}
              className="w-full py-3 px-4 rounded-xl bg-[#231a37] hover:bg-[#2d2146] border border-pink-500/40 text-pink-200 hover:text-white font-extrabold text-xs shadow-md active:scale-98 transition-all flex items-center justify-center gap-2.5"
            >
              <Smartphone className="w-4 h-4 text-pink-400" />
              <span>Telefon Numarası ile Giriş</span>
            </button>

            <div className="pt-2 text-center">
              <span className="text-[11px] text-gray-400">
                Giriş yaparak{' '}
                <span className="text-pink-300 underline cursor-pointer">Kullanım Şartları</span>'nı
                kabul etmiş olursunuz.
              </span>
            </div>
          </div>
        )}

        {/* STATE 2: PHONE NUMBER INPUT */}
        {method === 'phone' && (
          <form onSubmit={handleSendOtp} className="mt-4 space-y-3">
            <p className="text-xs text-purple-200">
              Telefon numaranıza 6 haneli bir SMS onay kodu göndereceğiz.
            </p>

            <div className="flex gap-2">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="w-24 px-2 py-2.5 rounded-xl bg-[#100d1b] border border-[#37274e] text-xs text-white focus:outline-none focus:border-pink-500"
              >
                <option value="+90">🇹🇷 +90</option>
                <option value="+1">🇺🇸 +1</option>
                <option value="+49">🇩🇪 +49</option>
                <option value="+44">🇬🇧 +44</option>
                <option value="+994">🇦🇿 +994</option>
              </select>

              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="5XX XXX XX XX"
                maxLength={14}
                className="flex-1 px-3 py-2.5 rounded-xl bg-[#100d1b] border border-[#37274e] text-sm text-white focus:outline-none focus:border-pink-500"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={loading || !phoneNumber.trim()}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff4f91] to-[#9a68ff] text-white font-extrabold text-xs shadow-lg shadow-pink-500/25 hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{loading ? 'Kod Gönderiliyor...' : 'SMS Onay Kodu Gönder'}</span>
            </button>
          </form>
        )}

        {/* STATE 3: OTP CODE VERIFICATION */}
        {method === 'otp' && (
          <form onSubmit={handleVerifyOtp} className="mt-4 space-y-3">
            <p className="text-xs text-purple-200 text-center">
              <strong className="text-pink-300">{countryCode} {phoneNumber}</strong> numarasına gönderilen 6 haneli kodu yazın:
            </p>

            <div className="flex justify-center">
              <input
                type="text"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="123456"
                maxLength={6}
                className="w-48 py-2.5 text-center tracking-[8px] text-xl font-mono font-black rounded-xl bg-[#100d1b] border border-pink-500/60 text-amber-300 focus:outline-none"
                autoFocus
              />
            </div>

            <p className="text-[11px] text-gray-400 text-center">
              Test için örnek kod otomatik girildi: <strong className="text-white">123456</strong>
            </p>

            <button
              type="submit"
              disabled={loading || otpCode.length !== 6}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-xs shadow-lg hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{loading ? 'Doğrulanıyor...' : 'Girişi Tamamla'}</span>
            </button>
          </form>
        )}

        {/* Security Footer */}
        <div className="mt-4 pt-3 border-t border-[#291f3c] flex items-center justify-center gap-1.5 text-[10px] text-purple-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>256-Bit SSL Güvenli Doğrulama Altyapısı</span>
        </div>
      </div>
    </div>
  );
};
