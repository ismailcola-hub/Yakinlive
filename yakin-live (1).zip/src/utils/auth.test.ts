import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAdminCredentials, validatePhoneNumber, validateOtp } from './auth.ts';

test('validateAdminCredentials returns true for correct credentials', () => {
  assert.equal(validateAdminCredentials('admin', 'yakinlive2026'), true);
  assert.equal(validateAdminCredentials('ADMIN', 'yakinlive2026'), true);
  assert.equal(validateAdminCredentials('admin', 'wrongpass'), false);
  assert.equal(validateAdminCredentials('wronguser', 'yakinlive2026'), false);
  assert.equal(validateAdminCredentials('', ''), false);
});

test('validatePhoneNumber validates 10 to 13 digit phone numbers', () => {
  assert.equal(validatePhoneNumber('5551234567'), true);
  assert.equal(validatePhoneNumber('+90 555 123 45 67'), true);
  assert.equal(validatePhoneNumber('0555 123 45 67'), true);
  assert.equal(validatePhoneNumber('123'), false);
  assert.equal(validatePhoneNumber(''), false);
});

test('validateOtp validates exact 6 digit verification code', () => {
  assert.equal(validateOtp('123456'), true);
  assert.equal(validateOtp('000000'), true);
  assert.equal(validateOtp('12345'), false);
  assert.equal(validateOtp('1234567'), false);
  assert.equal(validateOtp('abc123'), false);
});
