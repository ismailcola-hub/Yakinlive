export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  email?: string;
  phoneNumber?: string;
  provider: 'google' | 'facebook' | 'phone' | 'guest';
  isVerified: boolean;
  isAdmin: boolean;
}

export const DEFAULT_ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'yakinlive2026',
};

/**
 * Validates admin credentials
 */
export function validateAdminCredentials(username: string, pass: string): boolean {
  if (!username || !pass) return false;
  return (
    username.trim().toLowerCase() === DEFAULT_ADMIN_CREDENTIALS.username &&
    pass.trim() === DEFAULT_ADMIN_CREDENTIALS.password
  );
}

/**
 * Validates phone numbers (standard international / Turkish 10 digits)
 */
export function validatePhoneNumber(phone: string): boolean {
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 10 && digits.length <= 13;
}

/**
 * Validates 6-digit SMS OTP code
 */
export function validateOtp(code: string): boolean {
  const clean = code.trim();
  return /^\d{6}$/.test(clean);
}
